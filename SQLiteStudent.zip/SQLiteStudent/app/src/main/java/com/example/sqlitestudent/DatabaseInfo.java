package com.example.sqlitestudent;

import android.provider.BaseColumns;

public class DatabaseInfo implements BaseColumns {
    public static final String TABLE_NAME="StudentTable";
    public static final String IDNO="Idno";
    public static final String StudentName="Name";
    public static final String StudentAddress="Address";
}
