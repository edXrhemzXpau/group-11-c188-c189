package com.example.sqlitestudent;

public class POJO {
    private String p_name;
    private String p_address;
    private int p_id;
    private String p_idno;

    public String getP_name() {
        return p_name;
    }
    public void setP_name (String p_name) {
        this.p_name = p_name;
    }
    public String getP_address(){
        return p_address;
    }
    public void setP_address(String p_address) {
        this.p_address = p_address;
    }
    public int getP_id() {
        return p_id;
    }
    public void setP_id(int p_id) {
        this.p_id = p_id;
    }
    public String getP_idno() {
        return p_idno;
    }
    public void setP_idno(String p_idno) {
        this.p_idno = p_idno;
    }
}
